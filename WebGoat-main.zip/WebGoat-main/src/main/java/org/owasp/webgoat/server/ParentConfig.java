package org.owasp.webgoat.server;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("org.owasp.webgoat.server")
public class ParentConfig {}
